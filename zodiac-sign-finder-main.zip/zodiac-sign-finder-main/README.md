![home page](./images/1.png)
![home page](./images/2.png)

## Zodiac Signs (12)

```
Aquarius January 20th — February 18th
Pisces February 19th — March 20th
Aries March 21 — April 19th
Taurus April 20th — May 20th
Gemini May 21 — June 20th
Cancer June 21 —July 22
Leo July 23rd — August 22
Virgo August 23 — September 22nd
Libra September 23 — October 22
Scorpio October 23rd — November 21
Sagittarius November 22 — December 21
Capricorn December 22nd — January 19th
```
